﻿import { useEffect, useMemo, useRef, useState } from "react";
import { appLogos } from "../data/appLogos";
import { journeySlides } from "../data/journeySlides";
import "../styles/journey-slider.css";
import "../styles/slide-1-opening.clean.css";

type VisibleNote = {
  id: number;
  text: string;
  exiting: boolean;
};

function getIcon(text: string) {
  const t = text.toLowerCase();

  if (/1st place|champion|award|achievement/.test(t)) return "\u{1F3C6}";
  if (/2nd place|second place/.test(t)) return "\u{1F948}";
  if (/3rd place|third place/.test(t)) return "\u{1F949}";
  if (/tsunami|earthquake|disaster|emergency/.test(t)) return "\u{1F30A}";
  if (/communication|radio|satellite|gps|network|vpn/.test(t)) return "\u{1F4E1}";
  if (/health|mother|newborn|referral|hiv|clinic|puskesmas|covid|vaccine/.test(t)) return "\u{1FA7A}";
  if (/system|application|database|platform|web-based|interoperability|dashboard|tool/.test(t)) return "\u{1F9E9}";
  if (/knowledge|learning|training|manual|capacity/.test(t)) return "\u{1F4D8}";
  if (/ai|model|prompt|testing|qa|reviewer|trainer/.test(t)) return "\u{1F916}";
  if (/governance|government|policy|roadmap|public service/.test(t)) return "\u{1F3DB}\uFE0F";

  return "\u2728";
}

function parseAchievementNote(text: string) {
  const match = text.match(/^Achievements?:\s*(.+)$/i);

  if (!match) return null;

  return {
    title: "Achievement",
    detail: match[1]
  };
}

function PlaneSvg({ active }: { active: boolean }) {
  if (!active) return null;

  return (
    <svg className="plane-svg fly" viewBox="0 0 900 420" aria-hidden="true">
      <path
        d="M60 310 C210 250 330 210 480 180 C610 150 720 135 840 118"
        fill="none"
        stroke="rgba(37,99,235,.28)"
        strokeWidth="4"
        strokeDasharray="12 14"
      />
      <g transform="translate(575 125) rotate(-12)">
        <path
          d="M0 48 L210 0 C226 -4 238 10 224 22 L150 82 L178 155 L148 164 L98 104 L42 125 L20 109 L58 78 L0 48Z"
          fill="rgba(15,23,42,.86)"
        />
        <path d="M72 70 L145 52" stroke="rgba(255,255,255,.65)" strokeWidth="7" strokeLinecap="round" />
      </g>
    </svg>
  );
}

function FlyingLetters({ text }: { text: string }) {
  return (
    <div className="journey-flying-letters" aria-hidden="true">
      {Array.from(text).map((char, index) => (
        <span
          key={`${char}-${index}`}
          style={{
            ["--letter-index" as string]: index,
            ["--letter-x" as string]: `${((index * 37) % 220) - 110}px`,
            ["--letter-y" as string]: `${((index * 53) % 180) - 90}px`,
            ["--letter-r" as string]: `${((index * 17) % 70) - 35}deg`
          }}
        >
          {char === " " ? "\u00A0" : char}
        </span>
      ))}
    </div>
  );
}

const logoPositions = [
  [78, 10],
  [12, 18],
  [54, 28],
  [30, 62],
  [82, 72],
  [48, 10],
  [16, 78],
  [70, 48],
  [38, 35],
  [88, 36],
  [8, 46],
  [58, 70],
  [24, 8],
  [46, 52],
  [74, 22]
];

function LogoWall() {
  return (
    <div className="journey-logo-wall" aria-label="AI application logo showcase">
      {appLogos.map((logo, index) => {
        const [x, y] = logoPositions[index % logoPositions.length];
        const cycle = Math.floor(index / logoPositions.length);
        const safeY = Math.max(y, 26);

        return (
          <figure
            key={logo.src}
            className="journey-logo-orbit"
            style={{
              ["--logo-x" as string]: `${x}%`,
              ["--logo-y" as string]: `${safeY}%`,
              ["--logo-delay" as string]: `${index * 0.72 + cycle * 0.18}s`,
              ["--logo-size" as string]: `${index % 5 === 0 ? 92 : index % 3 === 0 ? 78 : 68}px`
            }}
          >
            <img src={logo.src} alt={logo.name} draggable={false} />
            <figcaption>{logo.name}</figcaption>
          </figure>
        );
      })}
      <div className="journey-logo-thankyou">Thank you</div>
    </div>
  );
}


const SLIDE_FRAME_FOLDERS: Record<number, string> = {
  0: "/assets/slide-0/",
  1: "/assets/slide-1/",
  2: "/assets/slide-2/",
  3: "/assets/slide-3/",
  4: "/assets/slide-3b/",
  5: "/assets/slide-3c/",
  6: "/assets/slide-4a/",
  7: "/assets/slide-4b/",
  8: "/assets/slide-5/",
  9: "/assets/slide-6/",
  10: "/assets/slide-7/"
};

function getSafeSlideFrames(slideIndex: number, frames: string[]) {
  const allowedFolder = SLIDE_FRAME_FOLDERS[slideIndex];

  if (!allowedFolder) {
    return frames;
  }

  const safeFrames = frames.filter((frame) => frame.startsWith(allowedFolder));

  if (safeFrames.length !== frames.length) {
    console.warn(
      `[JourneySlider] Blocked cross-folder frame(s) on slide index ${slideIndex}. Allowed folder: ${allowedFolder}`,
      frames.filter((frame) => !frame.startsWith(allowedFolder))
    );
  }

  return safeFrames.length > 0 ? safeFrames : frames;
}
function sameFooterText(a?: string, b?: string) {
  const clean = (value?: string) =>
    (value || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/[.,;:!?'"“”‘’()[\]{}-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();

  const aa = clean(a);
  const bb = clean(b);

  return aa.length > 0 && aa === bb;
}

export function JourneySlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [frameIndex, setFrameIndex] = useState(0);
  const [notes, setNotes] = useState<VisibleNote[]>([]);
  const [storyExpanded, setStoryExpanded] = useState(false);
  const timers = useRef<number[]>([]);
  const firstAutoSlideIndex = useRef(0);

  const slide = journeySlides[currentSlide];

  const achievementMasterSlide = journeySlides[5];
  const forceAchievementNotes = [5, 6].includes(currentSlide);
  const activeSlideNotes = forceAchievementNotes
    ? (achievementMasterSlide.notes || [])
    : (slide.notes || []);
  const slideFrames = currentSlide === 1 ? (slide.frames || []) : getSafeSlideFrames(currentSlide, slide.frames || []);
  const frameCount = slideFrames.length || 1;
  const activeFrame = slideFrames[frameIndex % frameCount] || slideFrames[0] || "";
  const showAchievementHeading = currentSlide !== 7 && currentSlide !== 8 && ([5, 6].includes(currentSlide) || (currentSlide >= 7 && currentSlide <= 23));

    const customAchievementRunningText: Record<number, string[]> = {
    5: [
      "1995–1996 — Member of the Student Council (OSIS), SMA Negeri 1 Sabang",
      "1995 — 1st Place, Inter-Senior High School Student Speech Competition, Sabang District",
      "1995 — 4th Place, Inter-Senior High School Student Speech Competition, Aceh Provincial Level",
      "1996 — Finalist, Youth Scientific Writing Competition, Ministry of Education and Culture of the Republic of Indonesia",
      "1996 — 1st Place, Inter-Senior High School Student Speech Competition, Sabang District",
      "1996 — 4th Place, Inter-Senior High School Student Speech Competition, Aceh Provincial Level",
      "1996 — 1st Place, Student Scientific Writing Competition on the P-4 Program, Sabang Education and Culture Office",
      "1996 — Initiator of the Wall Magazine and Monthly Bulletin of SMA Negeri 1 Sabang",
      "1997 — Finalist, Youth Scientific Writing Competition, Ministry of Education and Culture of the Republic of Indonesia"
    ],
    6: [
      "1997–1998 — Chairperson, PMII Commissariat, External Campus Organization",
      "1998 — 2nd Place, University-Level Student Scientific Writing Competition, Syiah Kuala University",
      "1998–1999 — Secretary, Bridge Student Activity Unit (UKM Bridge), Internal Campus Organization",
      "1999 — 1st Place, University-Level Student Scientific Writing Competition, Syiah Kuala University",
      "1999 — 5th Place, National Student Scientific Writing Competition",
      "1999–2000 — Chairperson, Bridge Student Activity Unit (UKM Bridge), Internal Campus Organization",
      "1999–2001 — President, Sabang Youth and Student Association (IPPEMAS)",
      "2000 — 1st Place, University-Level Student Scientific Writing Competition, Syiah Kuala University",
      "2000 — 4th Place, National Student Scientific Writing Competition",
      "2000 — 1st Place, National Student Scientific Writing Competition, Faculty of Engineering Lustrum, Syiah Kuala University",
      "2001 — 1st Place, National Student Scientific Writing Competition on Maritime and Marine Affairs, Syiah Kuala University Dies Natalis",
      "2001–2002 — Selected Recipient, ExxonMobil Scholarship, National Selection"
    ],
  };

  const directAchievementNotes = customAchievementRunningText[currentSlide] || [];

  const [achievementQueueIndex, setAchievementQueueIndex] = useState(0);

  useEffect(() => {
    if (!directAchievementNotes.length) {
      setAchievementQueueIndex(0);
      return;
    }

    setAchievementQueueIndex(0);

    const maxIndex = Math.max(0, directAchievementNotes.length - 3);
    const interval = window.setInterval(() => {
      setAchievementQueueIndex(prev => {
        if (prev >= maxIndex) {
          window.clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 1800);

    return () => window.clearInterval(interval);
  }, [currentSlide, directAchievementNotes.length]);

  const visibleAchievementNotes = directAchievementNotes.slice(
    achievementQueueIndex,
    achievementQueueIndex + 3
  );


  

  
  


  const activeAchievementNotes = customAchievementRunningText[currentSlide] || slide.notes || [];

  const footerBadge = slide.badge;
  const footerTitle = sameFooterText(slide.title, footerBadge) ? "" : slide.title;
  const footerMetaTitle =
    sameFooterText(slide.h3, footerBadge) ||
    sameFooterText(slide.h3, footerTitle) ||
    sameFooterText(slide.h3, slide.summary)
      ? ""
      : slide.h3 || "";
  const footerSubtitle =
    sameFooterText(slide.h4, footerBadge) ||
    sameFooterText(slide.h4, footerTitle) ||
    sameFooterText(slide.h4, footerMetaTitle) ||
    sameFooterText(slide.h4, slide.summary)
      ? ""
      : slide.h4 || "";
  const footerSummary =
    sameFooterText(slide.summary, footerBadge) ||
    sameFooterText(slide.summary, footerTitle) ||
    sameFooterText(slide.summary, footerMetaTitle) ||
    sameFooterText(slide.summary, footerSubtitle)
      ? ""
      : slide.summary;

  const walkAnimationName = `journeyWalkSegmented${currentSlide}`;

  const walkKeyframeCss = useMemo(() => {
    if (slide.mode !== "walk" || !slide.walkSegments || slide.walkSegments.length === 0) {
      return "";
    }

    const total = slide.walkSegments.length;

    const frames = slide.walkSegments
      .map((segment, index) => {
        const start = (index / total) * 100;
        const end = ((index + 1) / total) * 100;

        return `
          ${start.toFixed(3)}% { left: ${segment.from}; }
          ${end.toFixed(3)}% { left: ${segment.to}; }
        `;
      })
      .join("\n");

    return `@keyframes ${walkAnimationName} {${frames}}`;
  }, [currentSlide, slide]);

  const baseSlideDuration = currentSlide === 1 ? Math.max(500, Number(slide.duration || 500)) : Math.max(900, Number(slide.duration || 2600));

  const getConfiguredNoteDelay = (index: number) => {
    if (slide.fastNoteDelaysMs && slide.fastNoteDelaysMs[index] !== undefined) {
      return slide.fastNoteDelaysMs[index];
    }

    const lineDelay = slide.fastNotes ? slide.fastNoteStepMs || 1500 : 700;

    if (!slide.fastNotes) return index * lineDelay;
    if (index === 0) return 0;
    if (index === 1) return 1500;
    if (index === 2) return 3000;
    if (index === 3) return 4500;

    return index * 1500;
  };

  const noteTimelineDuration = (() => {
    const items = activeSlideNotes;

    if (items.length === 0) return 0;

    const lastNoteDelay = getConfiguredNoteDelay(items.length - 1);
    const afterLastDelay = slide.fastAfterLastMs ?? 0;

    return lastNoteDelay + afterLastDelay;
  })();

  const slideDuration = Math.max(baseSlideDuration, noteTimelineDuration);

  const panelStyle = useMemo(() => {
    const style: React.CSSProperties = {
      ["--journey-duration" as string]: `${slideDuration}ms`,
      ["--journey-walk-start" as string]: slide.walkStart || "4%",
      ["--journey-walk-end" as string]: slide.walkEnd || "35%",
      ["--journey-accent" as string]: slide.accent || "#2563eb",
      ["--journey-accent-soft" as string]: slide.accentSoft || "rgba(37,99,235,.15)",
      ["--journey-walk-animation" as string]: slide.walkSegments?.length ? walkAnimationName : "journeyWalkAcross"
    };

    if (slide.background) {
      style.backgroundImage = `linear-gradient(135deg, rgba(223,248,255,.22), rgba(231,255,246,.24)), url("${slide.background}")`;
    }

    return style;
  }, [slide, slideDuration, walkAnimationName]);

  function clearTimers() {
    timers.current.forEach((timer) => window.clearTimeout(timer));
    timers.current = [];
  }

  function schedule(callback: () => void, delay: number) {
    const timer = window.setTimeout(callback, delay);
    timers.current.push(timer);
  }

  function goTo(index: number) {
    let next = index;

    if (index >= journeySlides.length) {
      next = firstAutoSlideIndex.current;
    } else if (index < 0) {
      next = journeySlides.length - 1;
    }

    setCurrentSlide(next);
  }

  function nextSlide() {
    goTo(currentSlide + 1);
  }

  function previousSlide() {
    goTo(currentSlide - 1);
  }

  function restart() {
    clearTimers();
    firstAutoSlideIndex.current = 0;
    setFrameIndex(0);
    setNotes([]);
    setCurrentSlide(0);
    setPlaying(true);
  }

  useEffect(() => {
    clearTimers();
    setFrameIndex(0);
    setNotes([]);

    const items = activeSlideNotes;

    if (items.length > 0) {
      const getNoteDelay = getConfiguredNoteDelay;

      items.forEach((text, index) => {
        schedule(() => {
          const nextNote = {
            id: currentSlide * 100 + index,
            text,
            exiting: false
          };

          setNotes((current) => {
            if (!slide.maxVisibleNotes || current.length < slide.maxVisibleNotes) {
              return [...current, nextNote];
            }

            const [oldest, ...rest] = current;

            if (oldest) {
              schedule(() => {
                setNotes((activeNotes) => activeNotes.filter((activeNote) => activeNote.id !== oldest.id));
              }, 260);
            }

            return oldest ? [{ ...oldest, exiting: true }, ...rest, nextNote] : [...rest, nextNote];
          });
        }, getNoteDelay(index));
      });
    }

    if (playing && frameCount > 1) {
      const frameSequenceMs = slide.frameSequenceMs || [];

      if (frameSequenceMs.length > 0) {
        frameSequenceMs.forEach((delay, index) => {
          schedule(() => {
            setFrameIndex(Math.min(index, frameCount - 1));
          }, Math.max(0, Math.min(delay, slideDuration - 50)));
        });
      } else {
        const loops = slide.frameLoops || 1;
        const totalSteps = Math.max(frameCount * loops, frameCount);
        const frameStep = Math.max(90, Math.floor(slideDuration / totalSteps));

        for (let step = 1; step <= totalSteps; step++) {
          schedule(() => {
            const nextFrame = step >= totalSteps ? frameCount - 1 : step % frameCount;
            setFrameIndex(nextFrame);
          }, step * frameStep);
        }
      }
    }

    if (playing) {
      schedule(() => {
        setCurrentSlide((value) => {
          if (value === 0) {
            firstAutoSlideIndex.current = 1;
          }

          const next = value + 1;
          return next >= journeySlides.length ? firstAutoSlideIndex.current : next;
        });
      }, slideDuration);
    }

    return clearTimers;
  }, [currentSlide, playing]);

  const noteStepMs = slide.fastNotes ? slide.fastNoteStepMs || 120 : 180;

  return (
    <section id="journey" className="journey-section">
      <div className="journey-grid">
        <aside className="journey-story">
          <p className="journey-eyebrow">My Life Journey</p>
          <p className={`journey-story-text ${storyExpanded ? "expanded" : ""}`}>
            An ICT4D professional with over 21 years of experience leading digital system development across government,
            NGOs, international programs, as well as national and local initiatives. My core strength lies in transforming
            complex real-world problems into scalable, standardized solutions. Notably, I have contributed to advancing AI
            development and training, as well as building web-based systems and applications that improve quality of life and
            empower communities. I have extensive experience in system architecture, API design, data integration, and leading
            cross-functional teams in multi-stakeholder environments. I combine strong technical capabilities with governance
            and operational insight, along with managerial strength and effective stakeholder communication, to deliver
            solutions that are not only functional but also sustainable and impactful at scale.
          </p>
          <button
            className="journey-read-more"
            type="button"
            onClick={() => setStoryExpanded((value) => !value)}
          >
            {storyExpanded ? "Show less" : "Read more"}
          </button>

          <div className="journey-motto">
            Transforming complexity into scalable solutions with global impact.
          </div>

          <div className="journey-control-row">
            <button className="journey-nav-btn" type="button" onClick={previousSlide} aria-label="Previous slide">
              {"\u2039"}
            </button>
            <button className="journey-nav-btn" type="button" onClick={nextSlide} aria-label="Next slide">
              {"\u203A"}
            </button>

            <div className="journey-dots">
              {journeySlides.map((_, index) => (
                <button
                  key={index}
                  className={`journey-dot ${index === currentSlide ? "active" : ""}`}
                  type="button"
                  onClick={() => goTo(index)}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>

          <div className="journey-actions-inline">
            <button className="journey-primary" type="button" onClick={() => setPlaying((value) => !value)}>
              {playing ? "\u23F8 Pause" : "\u25B6 Play"}
            </button>
            <button className="journey-primary" type="button" onClick={restart}>
              {"\u21BB Restart"}
            </button>
          </div>

          <div className="journey-progress">
            <div key={`${currentSlide}-${playing}`} className="journey-progress-bar" />
          </div>
        </aside>

        <article
          className={`journey-panel slide-${currentSlide + 1} early-slide-${currentSlide + 1} ${slide.mode} visual-${slide.visualSide || "left"} ${slide.logoWall ? "logo-wall-panel" : ""} ${slide.staticVisual ? "static-visual" : ""} ${slide.maxVisibleNotes ? "limited-notes" : ""} ${slide.typewriterNotes ? "typewriter-notes" : ""} ${playing ? "is-playing" : "is-paused"}`}
          style={panelStyle}
          data-slide-index={currentSlide}
        >
          {walkKeyframeCss && <style>{walkKeyframeCss}</style>}

          
          {currentSlide === 0 && (
            <div className="journey-opening-prologue">
              <span className="journey-opening-line journey-opening-line--one">Once upon a time.................</span>
              <span className="journey-opening-line journey-opening-line--two">A boy was born in Pidie Jaya. His name......</span>
            </div>
          )}

          <div className="journey-code-stack">
            <div className="journey-code-year" dangerouslySetInnerHTML={{ __html: slide.h1Html || slide.h1 }} />
            <div className="journey-code-place">{slide.h2}</div>
          </div>

          <div className="journey-visual-track">
            {currentSlide === 7 && (
              <FlyingLetters text="Finally, the moment I had been waiting for had arrived." />
            )}

            {/* CUSTOM ACHIEVEMENT TEXT RENDER START */}
            {visibleAchievementNotes.length > 0 && (
              <div className="journey-custom-achievement-notes queue-three-notes">
                {visibleAchievementNotes.map((text, index) => (
                  <div
                    key={`custom-achievement-${currentSlide}-${achievementQueueIndex}-${index}`}
                    className="journey-custom-achievement-note queue-visible"
                  >
                    <span>{getIcon(text)}</span>
                    <p>{text}</p>
                  </div>
                ))}
              </div>
            )}
            {/* CUSTOM ACHIEVEMENT TEXT RENDER END */}
{showAchievementHeading && (
              <div className="journey-achievement-heading">Achievement</div>
            )}

            {slide.logoWall ? (
              <LogoWall />
            ) : (
              <>


                {!(currentSlide === 1 && slide.mode === "bus") && (
                  <div className={`journey-visual-item ${currentSlide === 7 && activeFrame.includes("frame-1.png") ? "slide8-frame-one-active" : ""} ${currentSlide === 7 && !activeFrame.includes("frame-1.png") ? "slide8-flight-frame-active" : ""}` }>
                    {activeFrame && (
                      <img
                        className="journey-character-img"
                        src={activeFrame}
                        alt={slide.title || slide.h3 || slide.badge}
                        draggable={false}
                      />
                    )}
                  </div>
                )}

                <PlaneSvg active={Boolean(slide.planeMode)} />
              </>
            )}

            {!slide.logoWall && notes.length > 0 && currentSlide !== 6 && currentSlide !== 7 && (
              <div className={`journey-notes ${currentSlide === 5 ? "early-achievement-notes" : ""} ${currentSlide === 6 ? "early-university-notes" : ""} ${currentSlide === 9 ? "early-tsunami-notes" : ""} ${currentSlide === 10 ? "early-return-notes" : ""}`}>
                {notes.map((note) => {
                  const achievement = parseAchievementNote(note.text);
                  const displayText = achievement ? achievement.detail : note.text;

                  return (
                    <div
                      key={note.id}
                      className={`journey-note ${note.exiting ? "exit" : ""}`}
                      data-note-index={note.id - currentSlide * 100}
                      style={{
                        animationDelay: "0ms",
                        ["--note-type-duration" as string]: `${Math.min(1500, Math.max(480, displayText.length * 18))}ms`,
                        ["--note-type-steps" as string]: Math.min(72, Math.max(12, displayText.length))
                      }}
                    >
                      <span>{getIcon(note.text)}</span>
                      <p>{displayText}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {currentSlide === 1 && (
            <div
              className="journey-bus-cinematic-v2"
              aria-hidden="true"
              style={{
                position: "absolute",
                inset: 0,
                zIndex: 999,
                pointerEvents: "none",
                overflow: "hidden",
                display: "block",
                visibility: "visible",
                opacity: 1
              }}
            >
              {slideFrames[0] && (
                <img
                  className="journey-bus-cinematic-v2__lead"
                  src={slideFrames[0]}
                  alt=""
                  draggable={false}
                />
              )}
              {(slideFrames[1] || slideFrames[0]) && (
                <img
                  className="journey-bus-cinematic-v2__final"
                  src={slideFrames[1] || slideFrames[0]}
                  alt=""
                  draggable={false}
                />
              )}
            </div>
          )}

                    
                              
                              
                    {/* SLIDE2_BUS_FORCE_START */}
          <style>{`
            .slide2-frame4-static {
              position: absolute !important;
              inset: 0 !important;
              z-index: 2147483000 !important;
              display: block !important;
              visibility: visible !important;
              opacity: 1 !important;
              pointer-events: none !important;
              overflow: hidden !important;
            }

            .slide2-frame4-static__image {
              position: absolute !important;
              left: 50% !important;
              top: 47% !important;
              width: 75% !important;
              height: 58% !important;
              transform: translate(-50%, -50%) !important;
              display: block !important;
              visibility: visible !important;
              opacity: 1 !important;
              background-image: url("/assets/slide-1/frame-4.png") !important;
              background-repeat: no-repeat !important;
              background-size: contain !important;
              background-position: center center !important;
              filter:
                drop-shadow(0 26px 36px rgba(15, 23, 42, .20))
                drop-shadow(0 8px 14px rgba(15, 23, 42, .10)) !important;
            }

            @media (max-width: 760px) {
              .slide2-frame4-static__image {
                width: 82% !important;
                height: 52% !important;
                top: 48% !important;
              }
            }
          `}</style>

          {currentSlide === 1 && (
            <div className="slide2-frame4-static" aria-hidden="true">
              <div className="slide2-frame4-static__image" />
            </div>
          )}
          {/* SLIDE2_BUS_FORCE_END */}
          <div className="journey-ground" />
          <div className="journey-shadow" />

          <footer className={`journey-slide-footer ${currentSlide <= 7 ? "journey-slide-footer--early" : ""} ${!footerTitle ? "no-footer-title" : ""}`}>
            {footerBadge && <div className="journey-footer-badge">{footerBadge}</div>}
            {(footerMetaTitle || footerSubtitle) && (
              <div className="journey-footer-meta">
                {footerMetaTitle && <strong>{footerMetaTitle}</strong>}
                {footerSubtitle && <span>{footerSubtitle}</span>}
              </div>
            )}
            {footerTitle && <h3>{footerTitle}</h3>}
            {footerSummary && <p>{footerSummary}</p>}
          </footer>
        </article>
      </div>
    </section>
  );
}

export default JourneySlider;



















































