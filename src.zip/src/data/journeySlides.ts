﻿export type JourneyMode =
  | "opening"
  | "bus"
  | "walk"
  | "achievement"
  | "scene"
  | "split"
  | "plane"
  | "logo";

export type JourneySequenceStep = {
  at: number;
  frame: number;
  visible?: boolean;
  phase?: "grad" | "takeoff" | "fly" | "land";
};

export type JourneySlide = {
  mode: JourneyMode;
  duration: number;
  badge: string;
  h1: string;
  h1Html?: string;
  h2: string;
  h3?: string;
  h4?: string;
  title: string;
  summary: string;
  background?: string;
  frames: string[];
  frameLoops?: number;
  walkStart?: string;
  walkEnd?: string;
  walkSegments?: { from: string; to: string }[];
  accent?: string;
  accentSoft?: string;
  frameY?: number;
  rollingNotes?: boolean;
  notes?: string[];
  noteWindow?: number;
  sequence?: JourneySequenceStep[];
  planeMode?: boolean;
  footerLayout?: "single" | "professional";
  visualSide?: "left" | "right";
  staticVisual?: boolean;
  maxVisibleNotes?: number;
  logoWall?: boolean;
  typewriterNotes?: boolean;
  fastNotes?: boolean;
  fastNoteStepMs?: number;
  fastAfterLastMs?: number;
  fastNoteDelaysMs?: number[];
  frameSequenceMs?: number[];
};

export const journeySlides: JourneySlide[] =
[
    {
    "mode": "opening",
    "duration": 14500,
    "badge": "Born in Pidie, 5 October 1979",
    "h1": "Saifuddin Bin Abdullah Bin Rasyid",
    "h1Html": "Saifuddin Bin<br/><span class=\"journey-name-small\">Abdullah Bin Rasyid</span>",
    "h2": "",
    "h3": "Saifuddin Bin Abdullah Bin Rasyid, born to be legend for architecting intelligence platform and innovation.",
    "h4": "",
    "title": "",
    "summary": "Saifuddin Bin Abdullah Bin Rasyid, born to be legend for architecting intelligence platform and innovation.",
    "background": "/assets/slide-0/background.png",
    "frames": [],
    "footerLayout": "single",
    "accent": "#0ea5e9",
    "accentSoft": "rgba(14,165,233,.16)"
},
    {
    "mode": "bus",
    "duration": 1500,
    "badge": "New Place, New Hope, New Future",
    "h1": "1981",
    "h2": "The family moved to Sabang",
    "h3": "New Place, New Hope, New Future",
    "h4": "",
    "title": "New Place, New Hope, New Future",
    "summary": "The family moved to Sabang, opening a new chapter of childhood, school life, and personal growth.",
    "frames": [
        "/assets/slide-1/frame-1.png",
        "/assets/slide-1/frame-3.png"
    ],
    "footerLayout": "single",
    "accent": "#2563eb",
    "accentSoft": "rgba(37,99,235,.14)"
},
    {
    "mode": "walk",
    "duration": 4340,
    "badge": "Active in school activities, including Little Doctor and student competitions",
    "h1": "1985",
    "h2": "SD Negeri Batee Shok",
    "h3": "Active in school activities, including Little Doctor and student competitions",
    "h4": "",
    "title": "Active in school activities, including Little Doctor and student competitions",
    "summary": "School was not only about lessons; it was also about confidence, curiosity, and early participation in student activities.",
    "frames": [
        "/assets/slide-2/frame-1.png",
        "/assets/slide-2/frame-2.png",
        "/assets/slide-2/frame-3.png",
        "/assets/slide-2/frame-4.png",
        "/assets/slide-2/frame-5.png"
    ],
    "footerLayout": "single",
    "accent": "#16a085",
    "accentSoft": "rgba(22,160,133,.15)",
    "frameLoops": 2,
    "walkStart": "0%",
    "walkEnd": "30%",
    "walkSegments": [
      {
        "from": "0%",
        "to": "15%"
      },
      {
        "from": "15%",
        "to": "30%"
      }
    ],

    "notes": []
},
    {
    "mode": "walk",
    "duration": 4340,
    "badge": "Engaged in many student competitions and academic activities",
    "h1": "1991",
    "h2": "SMP Negeri 1 Kota Sabang",
    "h3": "Engaged in many student competitions and academic activities",
    "h4": "",
    "title": "Engaged in many student competitions and academic activities",
    "summary": "Junior high school became a place to sharpen discipline, academic courage, and teamwork through many school activities.",
    "frames": [
        "/assets/slide-3/frame-1.png",
        "/assets/slide-3/frame-2.png",
        "/assets/slide-3/frame-3.png",
        "/assets/slide-3/frame-4.png",
        "/assets/slide-3/frame-5.png"
    ],
    "footerLayout": "single",
    "accent": "#0c8bd8",
    "accentSoft": "rgba(12,139,216,.15)",
    "frameLoops": 2,
    "walkStart": "30%",
    "walkEnd": "58%",
    "walkSegments": [
      {
        "from": "30%",
        "to": "44%"
      },
      {
        "from": "44%",
        "to": "58%"
      }
    ],

    "notes": []
},
    {
    "mode": "walk",
    "duration": 3100,
    "badge": "Multiple achievements and school awards",
    "h1": "1994",
    "h2": "SMU Negeri 1 Kota Sabang",
    "h3": "Multiple achievements and school awards",
    "h4": "",
    "title": "Multiple achievements and school awards",
    "summary": "This period strengthened talent, discipline, and the courage to compete beyond the classroom.",
    "frames": [
        "/assets/slide-3b/frame-1.png",
        "/assets/slide-3b/frame-2.png",
        "/assets/slide-3b/frame-3.png",
        "/assets/slide-3b/frame-4.png",
        "/assets/slide-3b/frame-5.png"
    ],
    "footerLayout": "single",
    "accent": "#7b57d1",
    "accentSoft": "rgba(123,87,209,.15)",
    "frameLoops": 1,
    "walkStart": "58%",
    "walkEnd": "78%",
    "walkSegments": [
      {
        "from": "58%",
        "to": "78%"
      }
    ],

    "notes": []
},
    {
    "mode": "achievement",
    "duration": 7000,
    "badge": "Leadership, scientific curiosity, and student achievements",
    "h1": "1994",
    "h2": "SMU Negeri 1 Sabang City",
    "h3": "Leadership, scientific curiosity, and student achievements.",
    "h4": "Achievements became a bridge from talent to confidence.",
    "title": "Leadership, scientific curiosity, and student achievements.",
    "summary": "The achievement stage highlights early leadership, scientific writing, public speaking, and competitive growth.",
    "frames": [
        "/assets/slide-3c/standing.png"
    ],
    "footerLayout": "single",
    "accent": "#7b57d1",
    "accentSoft": "rgba(123,87,209,.15)",
    "rollingNotes": true,
    "noteWindow": 99,
    "fastNotes": true,
    "fastNoteDelaysMs": [
        0,
        1500,
        3000,
        4500,
        6000
    ],
    "fastAfterLastMs": 1000,
    "notes": [
        "1st place, P4 Speech Competition, Sabang City (1995)",
        "1st place, Scientific Writing Competition, Sabang City (1996)",
        "School-level leadership and organizational experience",
        "Built early confidence in public speaking and scientific thinking",
        "Learned that achievement grows through discipline, practice, and courage"
    ]
},
    {
    "mode": "walk",
    "duration": 9000,
    "badge": "University Years",
    "h1": "1997",
    "h2": "Faculty of Engineering, Syiah Kuala University",
    "h3": "University life expanded the horizon.",
    "h4": "Learning, leadership, and competition became part of the same journey.",
    "title": "University Years",
    "summary": "The university years shaped technical thinking, leadership capacity, and the habit of turning ideas into structured work.",
    "frames": [
        "/assets/slide-4a/frame-1.png",
        "/assets/slide-4a/frame-2.png",
        "/assets/slide-4a/frame-3.png",
        "/assets/slide-4a/frame-4.png",
        "/assets/slide-4a/frame-5.png",
        "/assets/slide-4a/frame-6.png"
    ],
    "footerLayout": "single",
    "accent": "#16a085",
    "accentSoft": "rgba(22,160,133,.15)",
    "frameLoops": 6,
    "walkStart": "0%",
    "walkEnd": "96%",
    "walkSegments": [
        {
            "from": "0%",
            "to": "16%"
        },
        {
            "from": "16%",
            "to": "34%"
        },
        {
            "from": "34%",
            "to": "52%"
        },
        {
            "from": "52%",
            "to": "68%"
        },
        {
            "from": "68%",
            "to": "96%"
        }
    ],
    "rollingNotes": true,
    "noteWindow": 99,
    "fastNotes": true,
    "fastNoteDelaysMs": [
        0,
        1500,
        3000,
        4500,
        6000
    ],
    "fastAfterLastMs": 1000,
    "notes": [
        "2nd place, University Student Scientific Writing Competition (1998)",
        "1st place, University Student Scientific Writing Competition (1999)",
        "5th place, National Student Scientific Writing Competition (1999)",
        "1st place, Faculty of Engineering Lustrum Scientific Writing Competition (2000)",
        "Campus life strengthened leadership, writing, and technical confidence"
    ]
},
  {
    "mode": "plane",
    "duration": 14700,
    "badge": "Ready to Fight in Greater Jakarta",
    "h1": "2003",
    "h2": "Bachelor Graduation & Departure",
    "h3": "Ready to Fight in Greater Jakarta",
    "h4": "",
    "title": "Ready to Fight in Greater Jakarta",
    "summary": "After graduation, the journey moved toward Greater Jakarta with hope, courage, and the willingness to begin a new professional chapter.",
    "frames": [
      "/assets/slide-4b/frame-1.png",
      "/assets/slide-4b/frame-2.png",
      "/assets/slide-4b/frame-3.png",
      "/assets/slide-4b/frame-4.png",
      "/assets/slide-4b/frame-5.png",
      "/assets/slide-4b/frame-6.png"
    ],
    "footerLayout": "single",
    "accent": "#0284c7",
    "accentSoft": "rgba(2,132,199,.15)",
    "rollingNotes": true,
    "noteWindow": 9999,
    "notes": [
      "Finally, the moment I had been waiting for had arrived."
    ],
    "planeMode": false,
    "fastNotes": true,
    "fastNoteStepMs": 1500,
    "fastAfterLastMs": 1000,
    "fastNoteDelaysMs": [
      0
    ],
    "frameSequenceMs": [
      3600,
      4700,
      5050,
      5400,
      5750,
      6100
    ]
  },
    {
    "mode": "walk",
    "duration": 8600,
    "badge": "",
    "h1": "2003",
    "h2": "Cilegon, Banten, Indonesia",
    "h3": "Starting from Zero",
    "h4": "",
    "title": "Starting from Zero",
    "summary": "The first professional steps were full of uncertainty, but every step built discipline, survival, and resilience.",
    "frames": [
        "/assets/slide-5/frame-1.png",
        "/assets/slide-5/frame-2.png",
        "/assets/slide-5/frame-3.png",
        "/assets/slide-5/frame-4.png",
        "/assets/slide-5/frame-5.png"
    ],
    "footerLayout": "single",
    "accent": "#f97316",
    "accentSoft": "rgba(249,115,22,.16)",
    "frameLoops": 3,
    "walkStart": "0%",
    "walkEnd": "30%",
    "walkSegments": [
        {
            "from": "0%",
            "to": "10%"
        },
        {
            "from": "10%",
            "to": "20%"
        },
        {
            "from": "20%",
            "to": "30%"
        }
    ],
    "rollingNotes": true,
    "noteWindow": 9999,
    "notes": [],
    "fastNotes": true,
    "fastNoteStepMs": 1500,
    "fastAfterLastMs": 1200,
    "fastNoteDelaysMs": [
        2600,
        4200,
        5800
    ]
},
    {
    "mode": "scene",
    "duration": 9500,
    "badge": "The earthquake and tsunami changed everything",
    "h1": "26 December 2004",
    "h2": "Aceh Province, Indonesia",
    "h3": "The earthquake and tsunami changed everything",
    "h4": "",
    "title": "The earthquake and tsunami changed everything",
    "summary": "The tsunami changed life forever and became the turning point toward emergency response, recovery work, and public service.",
    "frames": [
        "/assets/slide-6/frame-1.png",
        "/assets/slide-6/frame-2.png",
        "/assets/slide-6/frame-3.png",
        "/assets/slide-6/frame-4.png",
        "/assets/slide-6/frame-5.png"
    ],
    "footerLayout": "single",
    "accent": "#0f172a",
    "accentSoft": "rgba(15,23,42,.16)",
    "rollingNotes": true,
    "noteWindow": 9999,
    "notes": [
        "The earthquake and tsunami changed everything.",
        "The disaster became the turning point toward emergency response and recovery work.",
        "A new professional chapter began in Aceh."
    ],
    "fastNotes": true,
    "fastNoteStepMs": 1500,
    "fastAfterLastMs": 1200,
    "fastNoteDelaysMs": [
        3900,
        5400,
        6900
    ],
    "frameSequenceMs": [
        0,
        650,
        1300,
        1950,
        2600
    ],
    "typewriterNotes": true
},
    {
    "mode": "plane",
    "duration": 7200,
    "badge": "Returning home to make sure his family was safe",
    "h1": "December 2004",
    "h2": "Flight Back to Aceh",
    "h3": "Returning home to make sure his family was safe",
    "h4": "",
    "title": "Returning home to make sure his family was safe",
    "summary": "The journey home was filled with fear, prayer, and uncertainty after the disaster.",
    "frames": [
        "/assets/slide-7/frame-1.png"
    ],
    "footerLayout": "single",
    "accent": "#334155",
    "accentSoft": "rgba(51,65,85,.16)",
    "rollingNotes": true,
    "noteWindow": 9999,
    "notes": [
        "Returned home to make sure family members were safe.",
        "The flight back carried fear, prayer, and uncertainty.",
        "Family safety came first; service followed."
    ],
    "planeMode": true,
    "fastNotes": true,
    "fastNoteStepMs": 1500,
    "fastAfterLastMs": 900,
    "fastNoteDelaysMs": [
        700,
        2500,
        4400
    ]
},
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "WHO · Tsunami Emergency Response Program",
        "h1":  "January 2005",
        "h2":  "WHO Field Office, Aceh Province, Indonesia",
        "h3":  "Role: ICT Officer",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Coordinated communication across field offices and stakeholders; managed HF, VHF, VPN, GPS, satellite phones, and network operations; supported inter-agency communication, medical communication protocols, field security information flow, and communication equipment inventory.",
        "frames":  [
                       "/assets/slide-8/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#0284c7",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Emergency response begins with reliable communication tools: HF radio, VHF radio, VPN, GPS, satellite phones, and field communication equipment.",
                      "Good inventory and technology tools became a lifeline after the disaster.",
                      "Supported medical communication protocols, inter-agency coordination, field security information flow, and emergency communication operations."
                  ],
        "visualSide":  "left",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  10000,
        "badge":  "LGSP-USAID · Local Governance Support Program",
        "h1":  "September 2005",
        "h2":  "Aceh Province, Indonesia",
        "h3":  "Role: Local Government Management System Specialist",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Supported local government action plans across districts; strengthened capacity building and governance systems; supported public service improvement, complaint handling, citizen gateway, beneficiary data validation, BLUD system support, and post-tsunami e-government reconstruction in Aceh.",
        "frames":  [
                       "/assets/slide-9/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#2563eb",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "PUSKORINFO: information coordination support for post-tsunami governance work.",
                      "Data Validator tool: supported validation of duplicate and non-eligible beneficiary records.",
                      "e-Complaint Handling System for districts.",
                      "Citizen Gateway for DISKOMINFO, Aceh Province.",
                      "BLUD system support for Aceh Jaya.",
                      "Supported post-tsunami e-government reconstruction in Aceh."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500,
                                 5000,
                                 6500,
                                 8000
                             ]
    },
    {
        "mode":  "scene",
        "duration":  5500,
        "badge":  "Master Degree",
        "h1":  "June 2010",
        "h2":  "Magister of Management, Syiah Kuala University",
        "h3":  "Magister of Management",
        "h4":  "",
        "title":  "",
        "summary":  "Continued postgraduate study while working in demanding humanitarian and governance programs, strengthening management knowledge, leadership capacity, and long-term professional development.",
        "frames":  [
                       "/assets/slide-10/frame-1.png"
                   ],
        "footerLayout":  "single",
        "accent":  "#7c3aed",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Never stop learning.",
                      "Continued postgraduate study while working in demanding humanitarian and governance programs.",
                      "Strengthened management knowledge and leadership capacity."
                  ],
        "fastNotes":  true,
        "typewriterNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "PPSP · Settlement Sanitation Development Acceleration Program",
        "h1":  "2010",
        "h2":  "Bappeda Aceh Barat, Aceh Province, Indonesia",
        "h3":  "Role: City Facilitator",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Facilitated EHRA studies; supported medium-term local sanitation planning; supported formulation of city sanitation strategy documents and program memoranda; strengthened capacity of local water and sanitation working groups.",
        "frames":  [
                       "/assets/slide-11/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#059669",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Achievement: EHRA Survey Tool.",
                      "Final Strategy Sanitasi Kota (SSK) document for Aceh Barat District.",
                      "Supported better sanitation planning, healthier cities, and the translation of policy into action."
                  ],
        "visualSide":  "left",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "EMAS-USAID · Expanding Maternal and Neonatal Survival",
        "h1":  "2012",
        "h2":  "North Sumatra, Indonesia",
        "h3":  "Role: ICT Specialist",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Supported citizen gateway and electronic referral system design; supported mobile and internet applications; trained district health officials; supported ICT-based public health messaging and emergency referral communication systems.",
        "frames":  [
                       "/assets/slide-12/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#dc2626",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Achievement: Citizen Report Card digital tools.",
                      "SIJARIEMAS: emergency referral health application system.",
                      "Supported faster referrals to help save mothers and newborns."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  7000,
        "badge":  "USAID-SIAP · Complaint Handling System",
        "h1":  "2013",
        "h2":  "Ministry of Administrative Reform, Jakarta",
        "h3":  "Role: Complaint Handling System Consultant",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Assessed the existing complaint handling system; designed and modified the e-Complaint system; developed masterplan, roadmap, communication strategy, user manuals, SOP support, job descriptions, and staff training for KemenPANRB.",
        "frames":  [
                       "/assets/slide-13/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#0f766e",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Achievement: masterplan for transforming PO BOX 8000 from a manual complaint channel into an e-Complaint system.",
                      "Roadmap for e-Complaint implementation at KemenPANRB.",
                      "SIDUTA: web-based e-Complaint system for KemenPANRB.",
                      "SIDUTA was designed with potential interoperability across ministries, national agencies, provinces, and districts."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500,
                                 5000
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "USAID IKAT-US · ASEAN Knowledge Network",
        "h1":  "2014",
        "h2":  "ASEAN Regional Collaboration",
        "h3":  "Role: ICT Specialist",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Built and maintained the IKAT-US web-based Knowledge Resource Center; supported e-communication, knowledge sharing, cross-learning, website content management, outreach, and regional CSO network collaboration across ASEAN.",
        "frames":  [
                       "/assets/slide-15/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#0ea5e9",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Achievement: KRC-IKAT, a Knowledge Resource Center for CSOs across ASEAN countries.",
                      "Supported cross-country learning, knowledge exchange, and regional network connection.",
                      "Helped CSO networks learn, grow faster, and stay connected."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "Kemitraan · Reform The Reformer",
        "h1":  "2014–2015",
        "h2":  "Reform The Reformer, DFAT Project",
        "h3":  "Role: Communication Specialist",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Planned and designed communication and outreach strategies; managed writing, design, production, and dissemination of publications; developed storylines, media materials, social media campaigns, press releases, and media relations.",
        "frames":  [
                       "/assets/slide-17/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#f97316",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Achievement: BR-HUB, a web-based Knowledge Resource Center for bureaucratic reform in Indonesia.",
                      "Supported communication, outreach, and reform knowledge sharing.",
                      "Helped connect reform messages with public understanding and media engagement."
                  ],
        "visualSide":  "left",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "MSI · Ombudsman RI",
        "h1":  "2015",
        "h2":  "Ombudsman RI, Jakarta",
        "h3":  "Role: CMS Consultant / System Analyst",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Assessed SP4N, ORI CMS, and LAPOR roadmap; drafted technical recommendations; modified SIMPeL to support NPCHS connection; improved transparency and accessibility for complainants; formulated policy brief and final recommendations.",
        "frames":  [
                       "/assets/slide-14/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#334155",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Roadmap for data interoperability and integration.",
                      "Draft SIMPLe: internal application for Ombudsman RI to monitor public complaint handling feedback by ministries and agencies.",
                      "Supported transparency, accessibility, and improved case handling."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  5500,
        "badge":  "MSI · Komisi Informasi Pusat",
        "h1":  "2015–2016",
        "h2":  "Komisi Informasi Pusat, Jakarta",
        "h3":  "Role: CMS Consultant / System Analyst",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Analyzed CMS design and SOP; designed, coded, and modified the case management system; refined the application based on feedback; developed user and training manuals; delivered training and prepared roadmap for sustainability.",
        "frames":  [
                       "/assets/slide-16/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#1d4ed8",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "SIPSI: web-based application system for information dispute cases.",
                      "E-PPID: web-based application system for public information disclosure requests.",
                      "Supported case management, public information access, and transparency."
                  ],
        "visualSide":  "left",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    },
    {
        "mode":  "split",
        "duration":  8500,
        "badge":  "FHI 360 · LINKAGES",
        "h1":  "2016–2021",
        "h2":  "FHI 360, Jakarta, Indonesia",
        "h3":  "Role: ICT4D Advisor",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Provided technical support for mobile, digital, and web tools; trained community representatives, outreach workers, MOH staff, and partners; strengthened outreach and referrals; coordinated technical implementation, reporting, work plans, SOWs, and partner assistance.",
        "frames":  [
                       "/assets/slide-18/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#be123c",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Technical Assistance Tracking System: web-based internal application for FHI 360 LINKAGES Indonesia.",
                      "Outreach Databank: web-based application developed by FHI 360 and handed over to KPAP DKI Jakarta.",
                      "Client Management Database (CMD): web-based application for CSO partners of LINKAGES Indonesia.",
                      "Jak-track: web-based Mobile VCT scheduler used by CSO partners and connected to clinics and Puskesmas in Jakarta.",
                      "Updatestatus: public web-based individual risk assessment and HIV self-testing booking platform."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500,
                                 5000,
                                 6500
                             ]
    },
    {
        "mode":  "split",
        "duration":  14500,
        "badge":  "FHI 360 · EpiC",
        "h1":  "2021–2025",
        "h2":  "FHI 360 – EpiC, Jakarta, Indonesia",
        "h3":  "Role: ICT4D Manager",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Provided technical assistance for mobile, digital, and web-based tools; trained community and government partners; identified barriers to HIV service uptake; managed ICT4D consultants; coordinated with USAID, MOH, and partners; ensured quality delivery, timeframe, and budget alignment.",
        "frames":  [
                       "/assets/slide-19/frame-1.png"
                   ],
        "footerLayout":  "professional",
        "accent":  "#7c3aed",
        "accentSoft":  "rgba(37,99,235,.15)",
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "SEDAB: web-based Lost to Follow-Up tracking system and ARV drug resistance monitoring tool.",
                      "FASTER: integrated application for project planning, budgeting, implementation, procurement, event organizing, reconciliation reporting, inventory, and program narrative reporting.",
                      "Aku Peduli: web-based HIV partner notification application for CSO partners.",
                      "HIVST: web-based system for public HIV self-testing kit requests, connected to CSO partners, clinics, and Puskesmas.",
                      "Berani Bersama: integrated community outreach platform connected to government systems.",
                      "CT-Covid: web-based COVID-19 contact tracing application for key populations, integrated with government systems.",
                      "Vaccap: vaccine management and monitoring platform for COVID-19 vaccination programs in major provinces.",
                      "Ventilator: web-based e-learning system for health facility staff responding to COVID-19 emergency patients.",
                      "ThinkEpiC: information portal and e-learning system for the EpiC Indonesia project."
                  ],
        "visualSide":  "right",
        "staticVisual":  true,
        "maxVisibleNotes":  5,
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500,
                                 5000,
                                 6500,
                                 8000,
                                 9500,
                                 11000,
                                 12500
                             ]
    },
    {
        "mode":  "logo",
        "duration":  38000,
        "badge":  "Freelancer, Individual Consultant, Alignerr, NIPA, Outlier, Test IO, MSE",
        "h1":  "2025–2026",
        "h2":  "AI Developer \u0026 Trainer",
        "h3":  "Role: Programer, Reviewer \u0026 Trainer",
        "h4":  "",
        "title":  "Scope of Work",
        "summary":  "Designed AI-powered applications, created prompts and workflows, supported AI training and evaluation, performed software testing and app review, and contributed to market analysis, technology localization, and digital implementation support.",
        "frames":  [
                       "/assets/app-logos/slide-24-ai-composite.svg"
                   ],
        "footerLayout":  "professional",
        "accent":  "#111827",
        "accentSoft":  "rgba(17,24,39,.15)",
        "logoWall":  true,
        "rollingNotes":  true,
        "noteWindow":  9999,
        "notes":  [
                      "Freelancer / Individual Consultant portfolio.",
                      "AI developer, AI trainer, app reviewer, and app tester.",
                      "Modern AI work: Outlier, Alignerr, NIPA, Freelance AI, QA testing, application review, and AI-assisted development."
                  ],
        "visualSide":  "right",
        "fastNotes":  true,
        "fastNoteStepMs":  1500,
        "fastAfterLastMs":  650,
        "fastNoteDelaysMs":  [
                                 500,
                                 2000,
                                 3500
                             ]
    }
];


































